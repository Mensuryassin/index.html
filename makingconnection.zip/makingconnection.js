function hide(element){
    element.remove();
}
function hide(element){
    element.remove();
}